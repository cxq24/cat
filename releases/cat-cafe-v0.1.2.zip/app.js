(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));

  // src/data.js
  var CATS = [
    { id: "C01", name: "豆皮", fur: "长毛", tags: ["粘人", "会抢镜"], scratch: false, price: 0, color: "#d99141", description: "一团会主动靠过来的小太阳。" },
    { id: "C02", name: "霜降", fur: "短毛", tags: ["高冷"], scratch: false, price: 0, color: "#9ba9a3", description: "看起来没在听，其实全听见了。" },
    { id: "C03", name: "米粒", fur: "短毛", tags: ["怕生", "上镜"], scratch: false, price: 0, color: "#454c48", description: "躲在角落，也能偷偷占据镜头。" },
    { id: "C04", name: "月亮", fur: "无毛", tags: ["安静"], scratch: false, price: 40, color: "#c9958d", description: "安安静静，像一颗暖乎乎的月亮。" },
    { id: "C05", name: "闯祸", fur: "短毛", tags: ["爱拆家", "粘人"], scratch: true, price: 28, color: "#a98563", description: "很会交朋友，也很会拆朋友的袖口。" },
    { id: "C06", name: "夜游", fur: "长毛", tags: ["安静", "高冷"], scratch: false, price: 32, color: "#424b58", description: "一片会呼吸的、安静的小夜色。" },
    { id: "C07", name: "土豆", fur: "短毛", tags: ["温和"], scratch: false, price: 36, color: "#bb9e72", description: "腿短一点，耐心多一点。" },
    { id: "C08", name: "伯爵", fur: "短毛", tags: ["上镜", "高冷"], scratch: false, price: 55, color: "#817d8e", description: "每天有 30% 概率赏脸来店。" }
  ];
  var SEATS = [
    { id: "S01", name: "靠窗", tags: ["较亮", "较吵"], type: "靠窗", quiet: false, tree: false },
    { id: "S02", name: "安静角落", tags: ["安静", "少人经过"], type: "安静角落", quiet: true, tree: false },
    { id: "S03", name: "拍照角", tags: ["拍照", "靠近猫树"], type: "拍照角", quiet: false, tree: true },
    { id: "S04", name: "吧台", tags: ["安静", "可看店员"], type: "吧台", quiet: true, tree: false }
  ];
  var STATES = { happy: "心情好", sleep: "正在睡觉", camera: "想抢镜", quarrel: "刚吵过" };
  var ADJACENT = [["S01", "S03"], ["S02", "S04"]];
  var ITEMS = [
    { id: "wand", name: "逗猫棒", price: 18, text: "每天可叫醒一只睡觉的猫，让它心情好。" },
    { id: "cushion", name: "软垫", price: 18, text: "怕猫客人的诉求匹配分 +8，最高 30 分。" }
  ];
  var GUESTS = [
    { id: 1, name: "小禾", look: "背着相机的姑娘", quote: "想带几张猫片回去。我的鼻子比较挑毛。", need: "只想拍照", limits: ["只能短毛或无毛"], preferences: ["靠窗", "拍照角"], budget: 28, hue: "#b68566" },
    { id: 2, name: "阿宁", look: "抱着纸巾的上班族", quote: "今天想找个地方坐坐，有猫陪着就更好了。", need: "想被粘", limits: [], preferences: ["安静角落"], budget: 32, hue: "#869c89" },
    { id: 3, name: "果果一家", look: "牵着小朋友的家长", quote: "小朋友第一次来，想认识一位温柔的新朋友。", need: "带小孩", limits: ["不能被抓", "不要靠近猫树"], preferences: [], budget: 30, hue: "#c59652" },
    { id: 4, name: "小满", look: "站在门边轻轻张望", quote: "我有一点怕猫，可以从安静的那只开始吗？", need: "第一次来怕猫", limits: ["不要太吵"], preferences: ["安静角落", "吧台"], budget: 26, hue: "#8e8ca5" },
    { id: 5, name: "阿照", look: "捧着拍立得的学生", quote: "今天专心拍照，猫猫做自己就好。", need: "只想拍照", limits: [], preferences: ["拍照角"], budget: 30, hue: "#bd8278" },
    { id: 6, name: "林先生", look: "穿着干净的白衬衫", quote: "想和一只酷酷的猫，各坐各的发一会儿呆。", need: "不要太粘", limits: ["不要太粘"], preferences: ["靠窗"], budget: 28, hue: "#7b929a" },
    { id: 7, name: "周周", look: "夹着笔记本的自由职业者", quote: "赶一份小稿子，希望这一角能安静一点。", need: "要安静", limits: ["不要太吵"], preferences: ["安静角落", "吧台"], budget: 34, hue: "#a49676" },
    { id: 8, name: "桃桃", look: "戴着生日发箍的朋友", quote: "生日合照就差一只愿意抢镜的猫啦。", need: "只想拍照", limits: [], preferences: ["拍照角", "靠窗"], budget: 36, hue: "#bf8e99" },
    { id: 9, name: "小苏", look: "小心收好外套的客人", quote: "我对毛比较敏感，今天想和月亮打个招呼。", need: "过敏，但还是想来", limits: ["只能短毛或无毛"], preferences: [], budget: 32, hue: "#92a59c" },
    { id: 10, name: "陈姨一家", look: "带亲戚来歇脚", quote: "大家只想平平安安喝杯东西，别太热闹。", need: "带小孩", limits: ["不能被抓", "不要太吵"], preferences: ["安静角落"], budget: 38, hue: "#aa937a" },
    { id: 11, name: "小屿", look: "戴着耳机的独行客", quote: "想把今天调成静音，在角落坐一会儿。", need: "要安静", limits: ["不要太吵"], preferences: ["安静角落"], budget: 24, hue: "#859896" },
    { id: 12, name: "阿迟", look: "刚下班还没摘工牌", quote: "猫猫如果愿意路过我一下，今天就算圆满。", need: "想被粘", limits: [], preferences: [], budget: 22, hue: "#b4a07c" },
    { id: 13, name: "可可", look: "带着迷你摄影包", quote: "想拍一组店里的日常，背景别太闹腾就好。", need: "只想拍照", limits: ["不要靠近猫树"], preferences: ["拍照角"], budget: 40, hue: "#b28779" },
    { id: 14, name: "白先生", look: "特地绕路来的熟客", quote: "听说伯爵偶尔会来。今天能遇见它吗？", need: "点名伯爵", limits: [], preferences: ["靠窗", "吧台"], budget: 50, hue: "#7b8c79" }
  ];
  var REVIEWS = {
    5: ["这张合照，准备当半年的头像。", "本来来喝咖啡，结果被猫续了杯。", "它一靠过来，今天就变轻了。", "这一桌的幸福浓度刚刚好。", "猫没说话，但我觉得我们聊得很好。", "想给今天的接待多加一颗星。"],
    4: ["咖啡还温着，猫也刚好醒着。", "小小的猫咖，接住了一个普通下午。", "它允许我坐在它旁边，荣幸。", "今天的猫片库存够用一周。", "没有很热闹，刚好有一点陪伴。", "这只猫有自己的营业节奏。"],
    3: ["猫在上班，但好像在等下班。", "我们相视一眼，各自喝了口空气。", "来之前想摸猫，最后摸了摸杯子。", "合照里，猫比我更懂留白。", "今天先混个脸熟，下次再约。", "猫很有想法，我还在理解。"],
    2: ["它在看窗外，我在看它的后脑勺。", "这桌的气氛，主打各忙各的。", "照片里只有半只猫，也算来过。", "我带了期待，它带了起床气。", "感觉自己坐进了猫的午休时间。", "这次没对上频道，下次换一桌。"],
    1: ["猫的营业时间，和我的不太一致。", "我们唯一的默契，是同时转过头。", "来接我的，似乎只有这把椅子。", "猫走了，留下我和完整的咖啡。", "这一桌，猫比客人更想打烊。", "今天的相遇有一点点不合拍。"]
  };
  var EVENT_COPY = {
    fight: ["隔桌对视三秒，两位猫同事吵起来了。", "邻桌气氛有点炸毛"],
    limit: ["需求写在纸上，猫把纸当成了装饰。", "这一桌踩到了限制"],
    cold: ["我等它回头，它等我下班。", "猫咪开启了免打扰"],
    mischief: ["袖口被热情招待，线头先认识了猫。", "袖口遇上了拆迁队"],
    rare: ["今天的惊喜，是伯爵真的来上班了。", "稀有同事赏脸营业"],
    missing: ["伯爵没来，今天先和它的同事认识。", "没见到点名的那只猫"],
    full: ["今天的位置都被幸福占满了，下次早来。", "客满 / 猫不够"]
  };
  var catById = (id) => CATS.find((cat) => cat.id === id);
  var seatById = (id) => SEATS.find((seat) => seat.id === id);

  // src/game.js
  function createProgress(now = Date.now()) {
    return { version: 1, createdAt: now, updatedAt: now, seed: Math.floor(Math.random() * 2147483646) + 1, day: 1, days: {}, purchases: {}, unlockDays: {}, summary: null };
  }
  function validateProgress(value) {
    const integer = (number) => Number.isSafeInteger(number) && number >= 0;
    if (!value || value.version !== 1 || !integer(value.day) || value.day < 1 || !integer(value.seed) || !integer(value.createdAt) || !integer(value.updatedAt)) throw new Error("存档版本或格式无法识别，请保留原数据。");
    if (!value.days || Array.isArray(value.days) || typeof value.days !== "object" || !value.purchases || Array.isArray(value.purchases) || typeof value.purchases !== "object") throw new Error("存档记录格式不完整。");
    Object.entries(value.days).forEach(([day, record]) => {
      if (!/^[1-9]\d*$/.test(day) || !record || !integer(record.revenue) || !integer(record.score) || record.score > 400 || !integer(record.at) || Number(day) > value.day) throw new Error("营业记录无法识别。");
    });
    Object.entries(value.purchases).forEach(([id, at]) => {
      if (!priceOf(id) || !integer(at)) throw new Error("解锁记录无法识别。");
    });
    if (value.unlockDays) Object.entries(value.unlockDays).forEach(([id, day]) => {
      if (!priceOf(id) || !integer(day) || day < 1) throw new Error("解锁生效日期无法识别。");
    });
    if (value.summary) {
      const summary = value.summary;
      if (!integer(summary.day) || !value.days[summary.day] || !Array.isArray(summary.results) || summary.results.length < 3 || summary.results.length > 4) throw new Error("结算记录无法识别。");
      summary.results.forEach((result) => {
        if (!result || !GUESTS.some((guest) => guest.id === result.guestId) || result.catId !== null && !catById(result.catId) || result.seatId !== null && !seatById(result.seatId) || !integer(result.score) || result.score > 100 || !integer(result.income) || !integer(result.stars) || result.stars < 1 || result.stars > 5 || typeof result.review !== "string" || !Array.isArray(result.events) || result.events.some((event) => !EVENT_COPY[event])) throw new Error("结算明细无法识别。");
      });
    }
    return value;
  }
  function priceOf(id) {
    return (CATS.find((cat) => cat.id === id) || ITEMS.find((item) => item.id === id) || (id === "S04" ? { price: 30 } : {})).price || 0;
  }
  function wallet(progress) {
    return 20 + Object.values(progress.days).reduce((sum, day) => sum + day.revenue, 0) - Object.keys(progress.purchases).reduce((sum, id) => sum + priceOf(id), 0);
  }
  function unlocked(progress, id) {
    return ["C01", "C02", "C03", "S01", "S02", "S03"].includes(id) || Object.prototype.hasOwnProperty.call(progress.purchases, id);
  }
  function available(progress, id) {
    return unlocked(progress, id) && (!progress.unlockDays || !progress.unlockDays[id] || progress.unlockDays[id] <= progress.day);
  }
  function buy(progress, id, now = Date.now()) {
    if (!priceOf(id) || unlocked(progress, id) || wallet(progress) < priceOf(id)) return false;
    progress.purchases[id] = now;
    if (!progress.unlockDays) progress.unlockDays = {};
    progress.unlockDays[id] = progress.day + 1;
    progress.updatedAt = now;
    return true;
  }
  function mergeProgress(left, right) {
    validateProgress(left);
    validateProgress(right);
    const first = left.createdAt < right.createdAt || left.createdAt === right.createdAt && left.seed < right.seed ? left : right;
    const merged = __spreadProps(__spreadValues({}, first), { days: {}, purchases: {}, unlockDays: {}, day: Math.max(left.day, right.day), updatedAt: Math.max(left.updatedAt, right.updatedAt) });
    const dayKeys = /* @__PURE__ */ new Set([...Object.keys(left.days), ...Object.keys(right.days)]);
    dayKeys.forEach((day) => {
      const a = left.days[day];
      const b = right.days[day];
      merged.days[day] = !a ? b : !b ? a : a.at > b.at || a.at === b.at && JSON.stringify(a) > JSON.stringify(b) ? a : b;
    });
    const purchases = /* @__PURE__ */ new Map();
    [left, right].forEach((progress) => Object.entries(progress.purchases).forEach(([id, at]) => purchases.set(id, Math.min(purchases.get(id) || Infinity, at))));
    Array.from(purchases).sort((a, b) => a[1] - b[1] || a[0].localeCompare(b[0])).forEach(([id, at]) => {
      if (wallet(merged) >= priceOf(id)) {
        merged.purchases[id] = at;
        const dates = [left, right].filter((progress) => progress.purchases[id] === at).map((progress) => progress.unlockDays && progress.unlockDays[id] || 1);
        merged.unlockDays[id] = Math.min(...dates);
      }
    });
    const summaries = [left.summary, right.summary].filter((summary) => summary && merged.days[summary.day] && summary.at === merged.days[summary.day].at);
    summaries.sort((a, b) => b.day - a.day || b.at - a.at || JSON.stringify(b).localeCompare(JSON.stringify(a)));
    merged.summary = summaries[0] || null;
    return merged;
  }
  function seeded(seed) {
    let state = seed % 2147483647;
    return () => {
      state = state * 16807 % 2147483647;
      return (state - 1) / 2147483646;
    };
  }
  function shuffle(values, random) {
    const copy = values.slice();
    for (let index = copy.length - 1; index > 0; index--) {
      const other = Math.floor(random() * (index + 1));
      [copy[index], copy[other]] = [copy[other], copy[index]];
    }
    return copy;
  }
  function createDay(progress) {
    const random = seeded((progress.seed + progress.day * 104729) % 2147483646 + 1);
    const present = CATS.filter((cat) => available(progress, cat.id) && (cat.id !== "C08" || random() < 0.3));
    const cats = present.map((cat) => {
      const roll = random();
      const state = roll < 0.4 ? "happy" : roll < 0.65 ? "sleep" : roll < 0.85 || cat.id === "C08" ? "camera" : "quarrel";
      const others = present.filter((other) => other.id !== cat.id);
      return { id: cat.id, state, opponent: state === "quarrel" && others.length ? others[Math.floor(random() * others.length)].id : null };
    });
    if (progress.day === 1) cats.forEach((cat) => {
      cat.state = cat.id === "C01" ? "happy" : cat.id === "C02" ? random() < 0.5 ? "happy" : "sleep" : cat.state === "quarrel" ? "happy" : cat.state;
      cat.opponent = null;
    });
    const pool = GUESTS.filter((guest) => progress.day <= 2 ? guest.id <= 8 : guest.id <= 13);
    const guests = shuffle(pool, random).slice(0, 3).map((guest) => guest.id);
    if (progress.day >= 5 && random() < 0.2) {
      const rare = GUESTS.filter((guest) => [13, 14].includes(guest.id) && !guests.includes(guest.id));
      guests.push(rare[Math.floor(random() * rare.length)].id);
    }
    return { number: progress.day, cats, seats: SEATS.filter((seat) => available(progress, seat.id)).map((seat) => seat.id), guests, results: [], wandUsed: false };
  }
  function isAdjacent(first, second) {
    return ADJACENT.some((pair) => pair.includes(first) && pair.includes(second));
  }
  function unmetLimits(guest, cat, seat) {
    return guest.limits.filter((limit) => {
      if (limit === "只能短毛或无毛") return cat.fur === "长毛";
      if (limit === "不能被抓") return cat.scratch;
      if (limit === "不要太吵") return seat.tags.includes("较吵");
      if (limit === "不要靠近猫树") return seat.tree;
      if (limit === "不要太粘") return cat.tags.includes("粘人");
      return false;
    });
  }
  function requestMatch(guest, cat, seat, status) {
    const has = (tag) => cat.tags.includes(tag);
    const result = (score, reason) => ({ score, reason });
    switch (guest.need) {
      case "想被粘":
        if (has("粘人")) return status.state === "sleep" ? result(20, "".concat(cat.name, "性格粘人，但今天正在睡觉，陪伴感稍弱。")) : result(30, "".concat(cat.name, "性格粘人，今天也醒着，能主动陪伴。"));
        if (!has("高冷") && status.state === "happy") return result(20, "".concat(cat.name, "今天心情好，愿意接近人，性格里没有主动粘人的特质。"));
        return result(0, "".concat(cat.name).concat(status.state === "sleep" ? "今天正在睡觉" : "性格偏高冷", "，难以回应主动陪伴的心愿。"));
      case "只想拍照":
        if (has("爱拆家") && seat.tree) return result(0, "".concat(cat.name, "爱拆家，又坐在猫树旁，难以安稳完成拍摄。"));
        if (has("上镜") || has("会抢镜") || status.state === "camera") return result(30, "".concat(cat.name).concat(status.state === "camera" ? "今天想抢镜" : "有" + (has("上镜") ? "上镜" : "会抢镜") + "特质", "，很适合这次拍摄。"));
        return result(20, "".concat(cat.name, "可以配合普通拍摄，性格中没有上镜或抢镜特质；睡觉、毛长均不额外扣拍照分。"));
      case "带小孩":
        if (cat.scratch || has("爱拆家")) return result(0, "".concat(cat.name).concat(cat.scratch ? "可能抓人" : "爱拆家", "，难以满足小朋友需要的稳妥陪伴。"));
        return result(30, "".concat(cat.name, "不会抓人，也没有拆家特质，符合陪伴小朋友的需求。"));
      case "第一次来怕猫":
        if (has("爱拆家") || has("粘人") && status.state === "camera") return result(0, "".concat(cat.name).concat(has("爱拆家") ? "爱拆家" : "粘人又想抢镜", "，对第一次来、怕猫的客人过于热情。"));
        if ((has("安静") || has("高冷") || has("温和")) && status.state !== "camera") return result(30, "".concat(cat.name, "的").concat(cat.tags.join("、"), "性格，给第一次来的客人留出了空间。"));
        if (has("怕生") || has("安静") || has("高冷") || has("温和")) return result(20, "".concat(cat.name).concat(has("怕生") ? "也有些怕生，能保持距离，陪伴感稍弱" : "平时性格合适，但今天想抢镜", "。"));
        return result(0, "".concat(cat.name, "性格偏主动，暂时难以让怕猫的客人放松。"));
      case "要安静": {
        const calm = (has("安静") || has("高冷")) && status.state !== "camera";
        if (calm && seat.quiet) return result(30, "".concat(cat.name, "今天安静，").concat(seat.name, "也是安静座位，能专心歇一会儿。"));
        if (seat.quiet) return result(20, "".concat(seat.name, "很安静，").concat(cat.name).concat(status.state === "camera" ? "今天想抢镜" : "的性格里没有安静或高冷特质", "，本次符合安静环境，猫咪状态仅基本合适。"));
        if (calm) return result(20, "".concat(cat.name, "今天安静，").concat(seat.name, "属于").concat(seat.tags.join("、"), "的座位，环境还不够安静。"));
        return result(0, "猫咪状态和座位环境都不符合安静诉求。");
      }
      case "过敏，但还是想来":
        return cat.fur !== "长毛" ? result(30, "".concat(cat.name, "是").concat(cat.fur, "，符合这位客人明确提出的游戏内毛类需求。")) : result(0, "".concat(cat.name, "是长毛，与这位客人的毛类需求冲突。"));
      case "点名伯爵":
        return cat.id === "C08" ? result(30, "见到了点名的伯爵，心愿达成。") : result(0, "客人点名伯爵，本次安排的是".concat(cat.name, "。"));
      case "不要太粘":
        return has("粘人") ? result(0, "".concat(cat.name, "性格粘人，与想保持距离的心愿冲突。")) : result(30, "".concat(cat.name, "没有粘人特质，符合各自安静相处的心愿。"));
      default:
        return result(0, "这项心愿尚没有对应的匹配规则。");
    }
  }
  function evaluate(guest, cat, seat, status, day, progress) {
    const has = (tag) => cat.tags.includes(tag);
    const broken = unmetLimits(guest, cat, seat);
    const limitScore = guest.limits.length ? 40 * (guest.limits.length - broken.length) / guest.limits.length : 40;
    const request = requestMatch(guest, cat, seat, status);
    let match = request.score;
    if (guest.need === "第一次来怕猫" && available(progress, "cushion") && match < 30) {
      const bonus = Math.min(8, 30 - match);
      match += bonus;
      request.reason += " 软垫增加 ".concat(bonus, " 分。");
    }
    const seatScore = !guest.preferences.length || guest.preferences.includes(seat.type) ? 15 : 0;
    const fightingWith = day.results.filter((result) => {
      if (!result.catId || !isAdjacent(seat.id, result.seatId)) return false;
      const other = day.cats.find((entry) => entry.id === result.catId);
      return status.opponent === other.id || other.opponent === cat.id;
    });
    const atmosphere = fightingWith.length ? 0 : 15;
    const adjustment = status.state === "camera" ? guest.need === "只想拍照" ? 10 : guest.need === "第一次来怕猫" ? -10 : 0 : 0;
    const score = Math.max(0, Math.min(100, Math.round(limitScore + match + seatScore + atmosphere + adjustment)));
    const stars = score >= 90 ? 5 : score >= 75 ? 4 : score >= 60 ? 3 : score >= 40 ? 2 : 1;
    const rates = [0, 0.2, 0.35, 0.55, 0.7, 0.85];
    const income = Math.floor(guest.budget * rates[stars]) + (stars === 5 ? 8 : stars === 4 ? 4 : 0);
    const events = [];
    if (fightingWith.length) events.push("fight");
    if (broken.length) events.push("limit");
    if (guest.need === "想被粘" && (status.state === "sleep" || has("高冷")) && score < 60) events.push("cold");
    if (has("爱拆家") || cat.scratch && guest.limits.includes("不能被抓")) events.push("mischief");
    if (cat.id === "C08" && stars >= 4) events.push("rare");
    if (guest.need === "点名伯爵" && cat.id !== "C08") events.push("missing");
    const review = events.length ? EVENT_COPY[events[0]][0] : REVIEWS[stars][(day.number + guest.id + Number(cat.id.slice(1))) % REVIEWS[stars].length];
    const reasons = {
      limits: guest.limits.length ? broken.length ? "未满足".concat(broken.join("、"), "；").concat(guest.limits.length, " 项限制均分 40 分。") : "符合".concat(guest.limits.join("、"), "，限制项得满分。") : "客人没有额外限制，限制项计满分。",
      match: request.reason,
      seat: !guest.preferences.length ? "客人没有座位偏好，本项计满分。" : seatScore ? "".concat(seat.name, "命中了").concat(guest.preferences.join(" / "), "的偏好。") : "偏好".concat(guest.preferences.join(" / "), "，本次安排了").concat(seat.name, "。"),
      atmosphere: fightingWith.length ? "与".concat(fightingWith.map((result) => catById(result.catId).name).join("、"), "相邻，触发了当天的争吵关系。") : "在店气氛平稳，计满分。",
      adjustment: adjustment > 0 ? "今天想抢镜，拍照诉求额外 +10 分，总分最高 100。" : adjustment < 0 ? "今天想抢镜，让怕猫的客人有些紧张，额外 -10 分。" : ""
    };
    return { guestId: guest.id, catId: cat.id, seatId: seat.id, score, stars, income, events, review, broken, scoringVersion: 2, breakdown: { limits: limitScore, match, seat: seatScore, atmosphere, adjustment, reasons }, fightingWith: fightingWith.map((result) => result.catId) };
  }
  function admit(day, progress, catId, seatId) {
    if (day.results.length >= day.guests.length) throw new Error("今天已打烊。");
    const guest = GUESTS.find((entry) => entry.id === day.guests[day.results.length]);
    const freeCats = day.cats.filter((cat) => !day.results.some((result2) => result2.catId === cat.id));
    const freeSeats = day.seats.filter((id) => !day.results.some((result2) => result2.seatId === id));
    if (!freeCats.length || !freeSeats.length) {
      const result2 = { guestId: guest.id, catId: null, seatId: null, score: 0, stars: 1, income: Math.floor(guest.budget * 0.1), events: ["full"], review: EVENT_COPY.full[0], broken: [] };
      day.results.push(result2);
      return result2;
    }
    const status = freeCats.find((cat) => cat.id === catId);
    if (!status || !freeSeats.includes(seatId)) throw new Error("请选择一只空闲猫和一个空闲座位。");
    const result = evaluate(guest, catById(catId), seatById(seatId), status, day, progress);
    result.fightingWith.forEach((id) => {
      const previous = day.results.find((entry) => entry.catId === id);
      if (!previous.events.includes("fight")) previous.events.push("fight");
      previous.review = EVENT_COPY.fight[0];
    });
    day.results.push(result);
    return result;
  }
  function finishDay(progress, day, now = Date.now()) {
    if (day.results.length !== day.guests.length || progress.days[day.number]) return false;
    const summary = { day: day.number, at: now, results: JSON.parse(JSON.stringify(day.results)) };
    progress.days[day.number] = { revenue: day.results.reduce((sum, result) => sum + result.income, 0), score: day.results.reduce((sum, result) => sum + result.score, 0), at: now };
    progress.summary = summary;
    progress.updatedAt = now;
    return true;
  }
  function summaryDetails(summary) {
    const best = summary.results.filter((result) => result.catId).reduce((previous, result) => !previous || result.score >= previous.score ? result : previous, null);
    const event = summary.results.find((result) => result.events.length);
    const lowest = summary.results.reduce((previous, result) => result.score <= previous.score ? result : previous);
    return { best, review: (event || (lowest.stars < 4 ? lowest : best) || lowest).review, revenue: summary.results.reduce((sum, result) => sum + result.income, 0) };
  }

  // src/platform.js
  async function platformFor(scope = window) {
    const xhs = scope.xhs;
    const api = xhs && xhs.miniTool;
    let launchOptions = xhs && xhs.launchOptions;
    const read = (options) => {
      const raw = options && options.miniToolEnv && options.miniToolEnv.buildVersion;
      return /^[1-9]\d{6,}$/.test(String(raw)) && Number.isSafeInteger(Number(raw)) ? Math.floor(Number(raw) / 1e3) : null;
    };
    let version = read(launchOptions);
    if (version === null && api && typeof api.getLaunchOptions === "function") {
      try {
        launchOptions = await api.getLaunchOptions();
        version = read(launchOptions);
      } catch (e) {
      }
    }
    return { api, version, launchOptions, preview: Boolean(scope.__CAT_CAFE_PREVIEW__), supports: (minimum, methods) => version !== null && version >= minimum && Boolean(api) && methods.every((method) => typeof api[method] === "function") };
  }
  var LOCAL_KEY = "cat_cafe_reception_v1";
  var COLLECTION = "cat_cafe_progress_v1";
  var clone = (value) => JSON.parse(JSON.stringify(value));
  var isDenied = (error) => [1005, 1006, 10003].includes(Number(error && error.errCode));
  var SaveStore = class {
    constructor(platform, onChange = () => {
    }) {
      this.platform = platform;
      this.onChange = onChange;
      this.progress = null;
      this.localState = "loading";
      this.cloudState = "unavailable";
      this.pending = null;
      this.localQueue = Promise.resolve();
      this.syncing = null;
      this.readBlocked = false;
      this.cloudAvailable = platform.supports(9510, ["queryCloudStorage", "addCloudStorage", "updateCloudStorage"]);
      if (this.cloudAvailable) this.cloudState = "idle";
    }
    emit() {
      this.onChange();
    }
    async load() {
      if (!this.platform.supports(9460, ["getStorage", "setStorage"])) {
        this.localState = "unavailable";
        this.progress = createProgress();
        this.emit();
        return;
      }
      try {
        const result = await this.platform.api.getStorage({ key: LOCAL_KEY });
        if (!result || !Object.prototype.hasOwnProperty.call(result, "data")) throw new Error("无法确认存档读取结果。");
        const empty = result.data === null || result.data === "";
        const envelope = empty ? null : JSON.parse(result.data);
        this.progress = empty ? createProgress() : validateProgress(envelope.progress);
        this.pending = envelope && envelope.pending || null;
        this.localState = empty ? "new" : "saved";
      } catch (error) {
        this.readBlocked = true;
        this.localState = "read-error";
        this.loadError = error;
      }
      this.emit();
    }
    async retryLoad() {
      this.readBlocked = false;
      await this.load();
    }
    async save(progress = this.progress) {
      if (this.readBlocked) throw new Error("读取失败，已保留原存档。");
      this.progress = clone(progress);
      return this.writeLocal();
    }
    writeLocal() {
      if (!this.platform.supports(9460, ["setStorage"]) || this.readBlocked) return Promise.resolve(false);
      const envelope = JSON.stringify({ progress: this.progress, pending: this.pending });
      this.localState = "saving";
      this.emit();
      this.localQueue = this.localQueue.catch(() => {
      }).then(async () => {
        try {
          const result = await this.platform.api.setStorage({ key: LOCAL_KEY, data: envelope });
          if (!result || result.errMsg !== "setStorage:ok") throw new Error("保存结果未确认");
          this.localState = "saved";
          return true;
        } catch (e) {
          this.localState = "write-error";
          return false;
        } finally {
          this.emit();
        }
      });
      return this.localQueue;
    }
    async cloudRecords() {
      const records = [];
      const seen = /* @__PURE__ */ new Set();
      let cursor;
      do {
        const response = await this.platform.api.queryCloudStorage(__spreadValues({ collection: COLLECTION, limit: 100 }, cursor ? { cursor } : {}));
        if (!response || !Array.isArray(response.items)) throw new Error("云存档读取结果无效");
        response.items.forEach((record) => {
          if (!record.id || !record.content || record.content.kind !== "cat-cafe-save") throw new Error("云存档记录无法识别");
          validateProgress(record.content.progress);
          records.push(record);
        });
        cursor = response.nextCursor;
        if (cursor && seen.has(cursor)) throw new Error("云存档分页异常");
        seen.add(cursor);
      } while (cursor);
      return records.sort((a, b) => a.id.localeCompare(b.id));
    }
    async sync() {
      if (!this.cloudAvailable || this.readBlocked || !this.progress || this.localState === "unavailable") return false;
      if (this.syncing) return this.syncing;
      this.syncing = this.performSync().finally(() => {
        this.syncing = null;
      });
      return this.syncing;
    }
    async performSync() {
      this.cloudState = "syncing";
      this.emit();
      try {
        const records = await this.cloudRecords();
        let merged = this.progress;
        records.forEach((record) => {
          merged = mergeProgress(merged, record.content.progress);
        });
        this.progress = merged;
        if (this.pending) {
          const confirmed = records.some((record) => record.content.writeId === this.pending.writeId);
          if (!confirmed) {
            this.cloudState = "pending";
            await this.writeLocal();
            return false;
          }
          this.pending = null;
        }
        const content = { kind: "cat-cafe-save", writeId: String(Date.now()) + "-" + Math.random().toString(36).slice(2), progress: clone(merged) };
        if (new Blob([JSON.stringify(content)]).size > 6e4) {
          this.cloudState = "too-large";
          await this.writeLocal();
          return false;
        }
        const target = records[0];
        this.pending = { writeId: content.writeId, id: target ? target.id : null };
        if (!await this.writeLocal()) {
          this.cloudState = "error";
          this.pending = null;
          return false;
        }
        const response = target ? await this.platform.api.updateCloudStorage({ collection: COLLECTION, items: [{ id: target.id, content }] }) : await this.platform.api.addCloudStorage({ collection: COLLECTION, items: [{ content }] });
        const result = response && response.data && response.data[0];
        if (result && result.status === "SUCCESS") {
          this.pending = null;
          this.cloudState = "synced";
        } else if (result && result.status === "FAILED") {
          this.pending = null;
          this.cloudState = "error";
        } else this.cloudState = "pending";
        await this.writeLocal();
        return this.cloudState === "synced";
      } catch (error) {
        if (isDenied(error)) {
          this.cloudAvailable = false;
          this.cloudState = "unavailable";
          this.pending = null;
        } else this.cloudState = this.pending ? "pending" : "error";
        await this.writeLocal();
        return false;
      } finally {
        this.emit();
      }
    }
  };
  var Rankings = class {
    constructor(platform) {
      this.platform = platform;
      this.available = platform.supports(9510, ["submitScore", "getRankList", "getMyRank"]);
      this.supported = this.available;
      this.failureReason = this.available ? null : "unsupported";
      this.cache = /* @__PURE__ */ new Map();
    }
    async request(method, options) {
      let timeout;
      try {
        return await Promise.race([
          this.platform.api[method](options),
          new Promise((_, reject) => {
            timeout = setTimeout(() => reject(new Error("排行榜请求超时")), 8e3);
          })
        ]);
      } finally {
        clearTimeout(timeout);
      }
    }
    async submit(summary) {
      if (!this.available) return false;
      const total = summary.results.reduce((sum, result) => sum + result.score, 0);
      const score = Math.round(total / summary.results.length * 100) / 100;
      try {
        await this.request("submitScore", { board: 1, score });
        this.cache.clear();
        return true;
      } catch (error) {
        if (isDenied(error)) {
          this.available = false;
          this.failureReason = "permission";
        }
        return false;
      }
    }
    async list(period) {
      if (!this.supported) throw new Error("当前环境暂不支持排行榜");
      const cached = this.cache.get(period);
      if (this.available && cached && Date.now() - cached.at < 3e4) return cached.value;
      try {
        let rows;
        for (const delay of [0, 500, 1e3, 2e3, 4e3]) {
          if (delay) await new Promise((resolve) => setTimeout(resolve, delay));
          try {
            rows = await this.request("getRankList", { board: 1, period });
            break;
          } catch (error) {
            if (Number(error.errCode) !== 2002 || delay === 4e3) throw error;
          }
        }
        const mine = await this.request("getMyRank", { board: 1, period });
        if (!rows || !Array.isArray(rows.data) || !mine || !["EXACT", "OVER_LIMIT", "NO_SCORE", "NOT_PARTICIPATING"].includes(mine.status)) throw new Error("榜单数据暂不可用");
        const value = { rows: rows.data, mine };
        this.available = true;
        this.failureReason = null;
        this.cache.set(period, { at: Date.now(), value });
        return value;
      } catch (error) {
        if (isDenied(error)) {
          this.available = false;
          this.failureReason = "permission";
        } else this.failureReason = "network";
        throw error;
      }
    }
  };

  // src/layout.js
  var nonnegative = (value) => typeof value === "number" && Number.isFinite(value) && value >= 0;
  function visibleRectangle(rect, info) {
    return rect && nonnegative(rect.width) && rect.width > 0 && nonnegative(rect.height) && rect.height > 0 && nonnegative(rect.bottom) && (!nonnegative(info.windowHeight) || rect.top < info.windowHeight) && (!nonnegative(info.windowWidth) || rect.left < info.windowWidth);
  }
  function windowInsets(info) {
    if (!info || typeof info !== "object") return null;
    const safe = info.safeArea || {};
    const buttons = info.menuButtons || {};
    const rectangles = visibleRectangle(buttons.capsule, info) ? [buttons.capsule] : [buttons.back, buttons.me, buttons.share].filter((rect) => visibleRectangle(rect, info));
    const statusTop = nonnegative(info.statusBarHeight) && nonnegative(info.screenTop) ? Math.max(0, info.statusBarHeight - info.screenTop) : 0;
    const hasSafeTop = nonnegative(safe.top);
    if (!hasSafeTop && !rectangles.length && !statusTop) return null;
    const safeTop = hasSafeTop ? safe.top : statusTop;
    const height = Math.max(44, ...rectangles.map((rect) => rect.height));
    const alignment = rectangles.reduce((selected, rect) => !selected || rect.bottom > selected.bottom ? rect : selected, null);
    const top = alignment ? Math.max(safeTop, alignment.top + alignment.height / 2 - height / 2) : safeTop;
    const width = info.windowWidth || info.screenWidth;
    let left = 20;
    let right = 20;
    rectangles.forEach((rect) => {
      if (rect.left + rect.width / 2 < width / 2) left = Math.max(left, rect.right + 8);
      else right = Math.max(right, width - rect.left + 8);
    });
    const bottom = nonnegative(info.windowHeight) && nonnegative(safe.bottom) ? Math.max(0, info.windowHeight - safe.bottom) : null;
    return { top, bottom, height, left, right };
  }
  async function installWindowLayout(platform, scope = window) {
    const document2 = scope.document;
    const html = document2.documentElement;
    let latestInfo = platform.launchOptions && platform.launchOptions.miniToolEnv && platform.launchOptions.miniToolEnv.windowInfo;
    let requestNumber = 0;
    let resizeTimer;
    function apply(info) {
      const insets = windowInsets(info);
      if (insets) {
        html.style.setProperty("--app-top", insets.top + "px");
        if (insets.bottom !== null) html.style.setProperty("--app-bottom", insets.bottom + "px");
        html.style.setProperty("--nav-height", insets.height + "px");
        html.style.setProperty("--nav-left", insets.left + "px");
        html.style.setProperty("--nav-right", insets.right + "px");
      }
      const css = scope.getComputedStyle(document2.getElementById("app"));
      const top = parseFloat(css.paddingTop) || 0;
      const bottom = parseFloat(css.paddingBottom) || 0;
      const availableHeight = scope.innerHeight - top - bottom;
      html.classList.toggle("compact-window", availableHeight <= 780);
      html.classList.toggle("small-window", availableHeight <= 670);
      html.classList.toggle("short-window", availableHeight <= 600);
    }
    async function refresh() {
      apply(latestInfo);
      if (!platform.supports(9490, ["getWindowInfo"])) return;
      const current = ++requestNumber;
      try {
        const info = await platform.api.getWindowInfo();
        if (current === requestNumber && windowInsets(info)) {
          latestInfo = info;
          apply(info);
        }
      } catch (e) {
      }
    }
    apply(latestInfo);
    const initial = refresh();
    let timeout;
    await Promise.race([initial, new Promise((resolve) => {
      timeout = setTimeout(resolve, 800);
    })]);
    clearTimeout(timeout);
    const resized = () => {
      apply(latestInfo);
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(refresh, 100);
    };
    scope.addEventListener("resize", resized);
    scope.addEventListener("orientationchange", resized);
    document2.addEventListener("visibilitychange", () => {
      if (!document2.hidden) refresh();
    });
  }

  // src/app.js
  async function main() {
    const root = document.getElementById("app");
    const toastNode = document.getElementById("toast");
    const platform = await platformFor();
    await installWindowLayout(platform);
    const rankings = new Rankings(platform);
    let screen = "home";
    let day = null;
    let selection = { cat: null, seat: null };
    let toastTimer;
    let clickBusy = false;
    let rankPeriod = "week";
    let rankValue = null;
    let rankError = false;
    let rankLoading = false;
    let rankRequest = 0;
    let shopReturn = "home";
    let rankReturn = "home";
    let settingsReturn = "home";
    let rankSubmitting = false;
    let ready = false;
    let detailsOpen = false;
    const store = new SaveStore(platform, () => {
      if (ready) updateSaveIndicator();
    });
    const esc = (value) => String(value == null ? "" : value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
    const guestById = (id) => GUESTS.find((guest) => guest.id === id);
    const progress = () => store.progress;
    const currentGuest = () => guestById(day.guests[day.results.length]);
    const totalRevenue = () => Object.values(progress().days).reduce((sum, record) => sum + record.revenue, 0);
    const button = (text, action, kind = "primary", extra = "") => '<button class="button '.concat(kind, '" data-action="').concat(action, '" ').concat(extra, ">").concat(text, "</button>");
    function toast(message) {
      clearTimeout(toastTimer);
      toastNode.textContent = message;
      toastNode.classList.add("visible");
      toastTimer = setTimeout(() => toastNode.classList.remove("visible"), 3300);
    }
    function catArt(id, extra = "") {
      const cat = catById(id);
      return '<span class="cat-art '.concat(id, " ").concat(extra, '" role="img" aria-label="').concat(cat.name, "，").concat(cat.fur, '猫"><i class="tail"></i><i class="cat-body"></i><i class="ear left"></i><i class="ear right"></i><i class="cat-head"><i class="patch"></i><i class="stripe one"></i><i class="stripe two"></i><i class="eye left"></i><i class="eye right"></i><i class="muzzle"></i><i class="nose"></i><i class="whisker left"></i><i class="whisker right"></i></i><i class="paw left"></i><i class="paw right"></i>').concat(id === "C08" ? '<i class="bow"></i>' : "", "</span>");
    }
    function person(guest, small = false) {
      return '<span class="person '.concat(small ? "small" : "", " person-").concat(guest.id % 4, '" role="img" aria-label="').concat(esc(guest.look), '" style="--shirt:').concat(guest.hue, '"><i class="hair-back"></i><i class="person-body"></i><i class="face"><i class="bang"></i><i class="person-eye left"></i><i class="person-eye right"></i><i class="smile"></i></i></span>');
    }
    function statusLabel(status) {
      return status.state === "quarrel" ? "刚和".concat(catById(status.opponent).name, "吵过") : STATES[status.state];
    }
    function saveLabel() {
      if (store.localState === "read-error") return "读取失败 · 原存档已保留";
      if (store.localState === "unavailable") return "当前环境无法保存进度";
      if (store.localState === "write-error") return "本机保存未确认";
      if (store.localState === "saving") return "正在保存…";
      if (platform.preview) return "浏览器试玩 · 模拟本机存档";
      if (store.cloudState === "syncing") return "本机已保存 · 云端同步中";
      if (store.cloudState === "synced") return "本机已保存 · 云端已同步";
      if (store.cloudState === "pending") return "本机已保存 · 云端结果待确认";
      if (["error", "too-large"].includes(store.cloudState)) return "本机已保存 · 云端待同步";
      return "本机存档 · 云同步暂不可用";
    }
    function updateSaveIndicator() {
      document.querySelectorAll("[data-save-status]").forEach((node) => {
        node.textContent = saveLabel();
      });
      document.querySelectorAll(".save-footer").forEach((node) => {
        node.outerHTML = saveFooter();
      });
    }
    function header() {
      const titles = { cats: "今日猫咪", guest: "接待客人", arrange: "安排入座", feedback: "接待反馈", summary: "打烊结算", shop: "升级小店", ranks: "接待排行榜", settings: "存档帮助" };
      return '<header class="topbar">'.concat(screen === "home" ? '<span class="brand">猫咖接待</span>' : '<button class="nav-back" data-action="back" aria-label="'.concat(activeDay() ? "返回首页" : "返回上一页", '"><span aria-hidden="true">‹</span>返回</button><span class="nav-title">').concat(titles[screen], "</span>"), "</header>");
    }
    function activeDay() {
      return ["cats", "guest", "arrange", "feedback"].includes(screen);
    }
    function returnHome() {
      if (activeDay() && day.results.length && !progress().days[day.number] && !window.confirm("今天还没打烊，返回首页后会重开当天，未结算收入不会入账。要返回首页吗？")) return;
      day = null;
      selection = { cat: null, seat: null };
      go("home");
    }
    function back() {
      if (screen === "ranks") {
        rankRequest++;
        rankLoading = false;
        go(rankReturn);
        return;
      }
      if (screen === "shop") {
        go(shopReturn);
        return;
      }
      if (screen === "settings") {
        go(settingsReturn);
        return;
      }
      returnHome();
    }
    function saveFooter() {
      const needsHelp = ["read-error", "write-error", "unavailable"].includes(store.localState) || ["error", "pending", "too-large"].includes(store.cloudState);
      const action = store.localState === "write-error" ? '<button class="text-button" data-action="save-retry">重试保存</button>' : needsHelp ? '<button class="text-button" data-action="settings">查看存档问题</button>' : "";
      return '<div class="save-footer"><p class="save-status" data-save-status>'.concat(saveLabel(), "</p>").concat(action, "</div>");
    }
    function heading(eyebrow, title, description = "") {
      return '<div class="page-heading"><p class="eyebrow">'.concat(eyebrow, "</p><h1>").concat(title, "</h1>").concat(description ? '<p class="intro">'.concat(description, "</p>") : "", "</div>");
    }
    function homePage() {
      const completed = Boolean(progress().days[progress().day]);
      const planned = createDay(progress());
      const prior = progress().summary;
      return '<section class="home-page">\n    '.concat(heading("一间小店，几位猫同事", "把今天，<br>交给一场猫的相遇。"), '\n    <div class="hero"><img src="./assets/cafe.png" alt="阳光照进猫咖，豆皮、霜降和米粒正在等客人" width="1536" height="1024"><div class="open-sign">').concat(completed ? "今日已打烊" : "准备营业", '<span>CAT CAFÉ</span></div></div>\n    <div class="day-strip">\n      <div><span class="small-label">营业手册</span><strong>第 ').concat(progress().day, ' 天</strong></div>\n      <div><span class="small-label">').concat(completed ? "今日已接待" : "今日来客", "</span><strong>").concat(completed && prior ? prior.results.length : planned.guests.length, ' 桌</strong></div>\n      <div class="wallet-balance"><span class="small-label">金币余额</span><strong>').concat(wallet(progress()), '<small> 金币</small></strong></div>\n    </div>\n    <div class="home-description"><p>一位客人，一只猫，一个刚刚好的座位。</p><p>').concat(progress().day === 1 && !completed ? "初始 20 金币，营业收益在打烊后入账。" : "每次营业，约两分钟。", '</p></div>\n    <div class="home-actions">\n      ').concat(button(completed ? "翻开今日结算 <span>→</span>" : "挂上营业牌 <span>→</span>", completed ? "summary" : "open"), '\n      <div class="home-secondary"><button data-action="shop">升级小店</button><button data-action="ranks">接待排行榜 ↗</button></div>\n    </div>\n    ').concat(saveFooter(), '\n    <p class="art-credit">场景插画由 AI 辅助生成</p>\n  </section>');
    }
    function catsPage() {
      return "<section>".concat(heading("第 ".concat(day.number, " 天 · 营业前"), "今天，谁来上班？", day.number === 1 ? "先看猫的性格，再为客人选一位合拍同伴。" : "猫有自己的心情，今天的相遇也会不一样。"), '<div class="cat-roster">').concat(day.cats.map((status) => {
        const cat = catById(status.id);
        const canWake = available(progress(), "wand") && !day.wandUsed && status.state === "sleep";
        return '<article class="roster-row">'.concat(catArt(cat.id, status.state === "sleep" ? "sleeping" : ""), '<div><div class="roster-name"><h2>').concat(cat.name, "</h2><span>").concat(cat.fur, "</span></div><p>").concat(cat.tags.join(" · ")).concat(cat.scratch ? " · 会抓人" : "", '</p><span class="cat-state ').concat(status.state, '">').concat(statusLabel(status), "</span></div>").concat(canWake ? '<button class="wake-button" data-action="wake" data-id="'.concat(cat.id, '">逗一逗<br><span>每日一次</span></button>') : "", "</article>");
      }).join(""), "</div>").concat(unlocked(progress(), "C08") && !day.cats.some((cat) => cat.id === "C08") ? '<p class="notice">伯爵今天没来。它的出勤概率是 30%。</p>' : "", '<div class="page-bottom">').concat(button("开始接待 <span>→</span>", "guest"), '<span class="footnote">每只猫今天只接待一桌</span></div></section>');
    }
    function demand(guest, compact = false) {
      return '<div class="demand '.concat(compact ? "compact" : "", '"><div class="demand-row"><span>想要</span><strong>').concat(guest.need, '</strong></div><div class="demand-row"><span>限制</span><strong class="requirement">').concat(guest.limits.length ? guest.limits.join(" / ") : "没有特别限制", '</strong></div><div class="demand-row"><span>座位</span><strong>').concat(guest.preferences.length ? guest.preferences.join(" / ") : "坐哪里都好", '</strong><span class="budget">预算 ').concat(guest.budget, " ◉</span></div></div>");
    }
    function guestPage() {
      const guest = currentGuest();
      return '<section class="guest-page">'.concat(heading("第 ".concat(day.number, " 天 · 第 ").concat(day.results.length + 1, " / ").concat(day.guests.length, " 桌"), "门口，来了一位客人。"), '<div class="guest-portrait"><div class="portrait-sun"></div>').concat(person(guest), '<span class="guest-leaf" aria-hidden="true">✳</span></div><div class="guest-name"><h2>').concat(guest.name, "</h2><span>").concat(guest.look, "</span></div><blockquote>“").concat(guest.quote, '”</blockquote><div class="order-note"><span class="note-pin"></span><h3>这一桌的小心愿</h3>').concat(demand(guest), '</div><div class="page-bottom">').concat(button("去安排猫和座位 <span>→</span>", "arrange"), "</div></section>");
    }
    function seatButton(id) {
      if (!day.seats.includes(id)) return '<span class="floor-space" aria-hidden="true">留一点空白<br>给未来的新座位</span>';
      const seat = seatById(id);
      const occupied = day.results.find((result) => result.seatId === id);
      const selected = selection.seat === id;
      return '<button class="seat '.concat(id, " ").concat(occupied ? "occupied" : "", " ").concat(selected ? "selected" : "", '" data-action="seat" data-id="').concat(id, '" aria-pressed="').concat(selected, '" aria-label="').concat(seat.name, "，").concat(occupied ? "已占用，" + guestById(occupied.guestId).name + "与" + catById(occupied.catId).name : seat.tags.join("、"), '" ').concat(occupied ? "disabled" : "", '><span class="seat-icon ').concat(id, '" aria-hidden="true"><i></i><i></i></span><span class="seat-name">').concat(seat.name, '<span class="seat-check">').concat(selected ? "✓" : occupied ? "已入座" : "空闲", '</span></span><span class="seat-tags">').concat(occupied ? "".concat(guestById(occupied.guestId).name, " · ").concat(catById(occupied.catId).name) : seat.tags.join(" · "), "</span></button>");
    }
    function arrangePage() {
      const guest = currentGuest();
      const freeCats = day.cats.filter((cat) => !day.results.some((result) => result.catId === cat.id));
      const freeSeats = day.seats.filter((id) => !day.results.some((result) => result.seatId === id));
      const full = !freeCats.length || !freeSeats.length;
      const selectedCat = catById(selection.cat);
      const selectedSeat = seatById(selection.seat);
      const violations = selectedCat && selectedSeat ? unmetLimits(guest, selectedCat, selectedSeat) : [];
      return '<section class="arrange-page"><div class="arrange-title"><div><p class="eyebrow">第 '.concat(day.results.length + 1, " / ").concat(day.guests.length, " 桌</p><h1>给").concat(guest.name, '安排一下</h1></div><button class="text-button" data-action="guest">看客人</button></div>').concat(demand(guest, true), '<div class="section-label"><h2>选一个座位</h2><span>').concat(freeSeats.length, ' 个空闲</span></div><div class="floorplan"><div class="floor-row">').concat(seatButton("S01"), '<span class="adjacency" aria-label="靠窗和拍照角相邻">相邻</span>').concat(seatButton("S03"), '</div><div class="floor-aisle">过 道</div><div class="floor-row">').concat(seatButton("S02")).concat(day.seats.includes("S04") ? '<span class="adjacency" aria-label="安静角落和吧台相邻">相邻</span>' : "").concat(seatButton("S04"), '</div></div><div class="section-label cat-section-label"><h2>选一位猫同事</h2><span>').concat(freeCats.length, ' 只空闲</span></div><div class="cat-picker ').concat(day.cats.length <= 3 ? "three" : "", '">').concat(day.cats.map((status) => {
        const cat = catById(status.id);
        const occupied = day.results.find((result) => result.catId === cat.id);
        const selected = selection.cat === cat.id;
        return '<button class="cat-option '.concat(selected ? "selected" : "", " ").concat(occupied ? "occupied" : "", '" data-action="cat" data-id="').concat(cat.id, '" aria-pressed="').concat(selected, '" aria-label="').concat(cat.name, "，").concat(occupied ? "已占用，" + guestById(occupied.guestId).name : "".concat(cat.fur, "，").concat(cat.tags.join("、"), "，").concat(statusLabel(status)).concat(cat.scratch ? "，会抓人" : ""), '" ').concat(occupied ? "disabled" : "", ">").concat(catArt(cat.id, status.state === "sleep" ? "sleeping" : ""), '<span class="option-name">').concat(cat.name).concat(selected ? "<span>✓</span>" : "", '</span><span class="option-trait">').concat(cat.fur, " · ").concat(cat.tags.join(" / "), '</span><span class="option-state ').concat(status.state, '">').concat(occupied ? "".concat(guestById(occupied.guestId).name, " · 已占用") : statusLabel(status), "</span>").concat(cat.scratch && !occupied ? '<span class="scratch-label">会抓人</span>' : "", "</button>");
      }).join(""), '</div><div class="selection-summary" aria-live="polite"><span>').concat(full ? "今天的猫或座位已经用完了" : "".concat(selectedCat ? selectedCat.name : "未选猫", " ＋ ").concat(selectedSeat ? selectedSeat.name : "未选座位"), '</span><button data-action="reset" ').concat(!selection.cat && !selection.seat ? "disabled" : "", ">重选</button></div>").concat(violations.length ? '<p class="warning" role="status">会踩限制 · '.concat(violations.join("、"), "。仍可安排入座。</p>") : "", '<div class="arrange-bottom">').concat(button(full ? "向客人说明，送别这一桌" : "安排入座 <span>→</span>", "admit", full ? "secondary" : "primary", !full && (!selection.cat || !selection.seat) ? "disabled" : ""), "</div></section>");
    }
    function pairArt(result) {
      return '<div class="pair-art">'.concat(person(guestById(result.guestId)), '<span class="pair-heart" aria-hidden="true">♡</span>').concat(result.catId ? catArt(result.catId) : '<span class="empty-chair" aria-hidden="true">再会</span>', '<span class="table-line"></span></div>');
    }
    function feedbackPage() {
      const result = day.results[day.results.length - 1];
      const event = result.events[0];
      const breakdown = result.breakdown;
      const reasons = breakdown && breakdown.reasons || {};
      const matchLabel = breakdown && (breakdown.match >= 30 ? "完全合拍" : breakdown.match > 0 ? "基本合拍" : "心愿未满足");
      const scoreRows = breakdown ? [
        ["限制", "limits", 40],
        ["诉求匹配", "match", 30],
        ["座位", "seat", 15],
        ["气氛", "atmosphere", 15]
      ].map(([label, key, max]) => '<div class="score-detail"><div><span>'.concat(label, "</span><strong>").concat(breakdown[key], " / ").concat(max, "</strong></div><p>").concat(esc(reasons[key] || "此记录使用旧版评分规则。"), "</p></div>")).join("") : "";
      return '<section class="feedback-page">\n    '.concat(heading("第 ".concat(day.results.length, " 桌 · ").concat(result.seatId ? seatById(result.seatId).name : "门口"), event ? EVENT_COPY[event][1] : result.stars >= 4 ? "这一次，刚刚好。" : "猫有自己的想法。"), "\n    ").concat(pairArt(result), '\n    <div class="stars" aria-label="').concat(result.stars, ' 星"><span>').concat("★".repeat(result.stars), '</span><span class="empty-stars">').concat("☆".repeat(5 - result.stars), "</span></div>\n    <blockquote>“").concat(result.review, '”</blockquote>\n    <div class="feedback-income"><span>本桌收入</span><strong>+').concat(result.income, "<small> ◉</small></strong><span>").concat(result.score, " 分</span></div>\n    ").concat(breakdown ? '<p class="match-explanation"><strong>'.concat(matchLabel, " · 诉求 ").concat(breakdown.match, " / 30</strong>").concat(esc(reasons.match || "旧版评分将部分匹配计为 12 分。"), "</p>") : "", '\n    <button class="text-button score-toggle" data-action="details" aria-expanded="').concat(detailsOpen, '">').concat(detailsOpen ? "收起" : "看看为什么", " ").concat(detailsOpen ? "−" : "+", "</button>\n    ").concat(detailsOpen && breakdown ? '<div class="score-details">'.concat(scoreRows).concat(breakdown.adjustment ? '<div class="score-detail"><div><span>状态修正</span><strong>'.concat(breakdown.adjustment > 0 ? "+" : "").concat(breakdown.adjustment, "</strong></div><p>").concat(esc(reasons.adjustment), "</p></div>") : "", "</div>") : "", '\n    <div class="page-bottom">').concat(button(day.results.length === day.guests.length ? "挂上打烊牌 <span>→</span>" : "接待下一位 <span>→</span>", "continue"), '<span class="footnote">今日暂收 ').concat(day.results.reduce((sum, entry) => sum + entry.income, 0), " 金币，打烊后入账</span></div>\n  </section>");
    }
    function summaryPage() {
      const summary = progress().summary;
      if (!summary) return homePage();
      const { best, review, revenue } = summaryDetails(summary);
      const average = (summary.results.reduce((sum, result) => sum + result.score, 0) / summary.results.length).toFixed(1);
      return '<section class="summary-page">'.concat(heading("第 ".concat(summary.day, " 天 · 打烊手记"), "今天最合拍的一对。"), '<div class="summary-print"><span class="print-stamp">好好相遇</span>').concat(best ? pairArt(best) : '<div class="no-pair">今天先休息一下</div>', '<div class="pair-names">').concat(best ? "".concat(guestById(best.guestId).name, "<span>＆</span>").concat(catById(best.catId).name) : "明天，再来一次", "<small>").concat(best ? seatById(best.seatId).name + "的一次相遇" : "总有合拍的下一桌", '</small></div><div class="receipt-edge"></div><div class="receipt-totals"><div><span>今日营业额</span><strong>').concat(revenue, "<small> 金币</small></strong></div><div><span>平均接待分</span><strong>").concat(average, '<small> / 100</small></strong></div></div><div class="review-note"><span>留在留言簿上的一句话</span><blockquote>“').concat(review, '”</blockquote></div><div class="receipt-footer">今日接待 ').concat(summary.results.length, " 桌<span>累计金币 ").concat(wallet(progress()), '</span></div></div><div class="summary-actions">').concat(button("开店，迎接下一天 <span>→</span>", "next-day"), '<div class="secondary-row">').concat(button("升级小店", "shop", "secondary")).concat(button("分享今天 ↗", "share-menu", "secondary"), '</div><button class="text-button rank-link" data-action="ranks">去看看接待排行榜 ↗</button></div>').concat(saveFooter(), "</section>");
    }
    function shopPage() {
      const today = createDay(progress());
      const upgrades = [...CATS.filter((cat) => cat.price).map((cat) => __spreadProps(__spreadValues({}, cat), { type: "cat", text: "".concat(cat.fur, " · ").concat(cat.tags.join("、")).concat(cat.scratch ? " · 会抓人" : "") })), { id: "S04", name: "吧台座位", price: 30, type: "seat", text: "安静、可看店员；与安静角落相邻。" }, ...ITEMS.map((item) => __spreadProps(__spreadValues({}, item), { type: "item" }))];
      return '<section class="shop-page">'.concat(heading("给明天，留一点新期待", "店里添点什么？", "新朋友、新座位和小物件，从下一天开始可用。"), '<div class="wallet-panel"><span>可用金币</span><strong>').concat(wallet(progress()), "<small> 金币</small></strong></div>").concat(progress().day >= 4 ? '<p class="notice">往后可能有第 4 桌。多一只猫、多一个座位，会从容一点。</p>' : "", '<div class="shop-list">').concat(upgrades.map((item) => {
        const owned = unlocked(progress(), item.id);
        const affordable = wallet(progress()) >= item.price;
        return '<article class="shop-row">'.concat(item.type === "cat" ? catArt(item.id) : '<span class="shop-object '.concat(item.id, '" aria-hidden="true">').concat(item.id === "S04" ? "▤" : item.id === "wand" ? "〰" : "▱", "</span>"), '<div class="shop-info"><h2>').concat(item.name, "</h2><p>").concat(item.text, "</p>").concat(item.id === "C08" ? "<small>每日 30% 概率到店".concat(owned && !today.cats.some((cat) => cat.id === "C08") ? " · 今天没来" : "", "</small>") : "", '</div><button class="buy-button ').concat(owned ? "owned" : "", '" data-action="buy" data-id="').concat(item.id, '" ').concat(owned || !affordable ? "disabled" : "", ">").concat(owned ? "已解锁" : "".concat(item.price, " ◉")).concat(!owned && !affordable ? "<small>还差 ".concat(item.price - wallet(progress()), "</small>") : "", "</button></article>");
      }).join(""), '</div><div class="page-bottom">').concat(button("回到小店 <span>→</span>", "shop-back", "secondary"), "</div></section>");
    }
    function ranksPage() {
      const mine = rankValue && rankValue.mine;
      const unavailable = (!rankings.supported || rankings.failureReason === "permission") && !rankLoading;
      const message = rankings.failureReason === "permission" ? "当前小工具的排行榜权限尚未开通，开放后即可查看。" : unavailable ? "当前环境暂不支持排行榜，可以先继续营业。" : "榜单暂时加载失败，请稍后重试。";
      return '<section class="ranks-page">\n    '.concat(heading("和大家，比一比接待手艺", "接待排行榜", "按单日平均接待分排名，同周期保留最好成绩。"), "\n    ").concat(!unavailable ? '<div class="tabs" role="tablist" aria-label="榜单周期">'.concat([["week", "周榜"], ["all", "总榜"]].map(([period, label]) => '<button role="tab" aria-selected="'.concat(rankPeriod === period, '" class="').concat(rankPeriod === period ? "active" : "", '" data-action="period" data-id="').concat(period, '">').concat(label, "</button>")).join(""), "</div>") : "", "\n    ").concat(rankError || unavailable ? '<div class="empty-state" role="status"><h2>'.concat(unavailable ? "排行榜暂未开放" : "暂时没能加载榜单", "</h2><p>").concat(message, "</p>").concat(rankings.supported ? button("重新尝试", "load-rank", "secondary") : "", "</div>") : !rankValue ? '<p class="empty-state" role="status">正在翻开接待榜…</p>' : '<div class="my-rank"><span>我的排名</span><strong>'.concat(mine.status === "EXACT" ? mine.rank : mine.status === "OVER_LIMIT" ? "500+" : "暂无成绩", "</strong><small>").concat(mine.status === "EXACT" ? mine.score + " 分" : "完成营业后提交成绩", "</small></div>\n        ").concat(!rankValue.rows.length ? '<p class="empty-state">这一期还没有成绩，等第一位接待员上榜。</p>' : '<ol class="rank-list">'.concat(rankValue.rows.map((row) => '<li><span class="rank-number">'.concat(esc(row.rank), "</span><span>").concat(esc(row.nickname || "猫咖来客"), "</span><strong>").concat(esc(row.score), "<small> 分</small></strong></li>")).join(""), "</ol>")), "\n    ").concat(!unavailable ? '<p class="footnote">周榜每周一北京时间 0 点开启新一期。</p>' : "", "\n    ").concat(progress().summary && rankings.available ? '<button class="text-button score-toggle" data-action="submit-rank" '.concat(rankSubmitting ? "disabled" : "", ">").concat(rankSubmitting ? "正在提交…" : "提交最近一次接待成绩", "</button>") : "", '\n    <div class="page-bottom">').concat(button("返回", "back", "secondary"), "</div>\n  </section>");
    }
    function settingsPage() {
      const cloudTexts = { unavailable: "云存档为内测能力，当前未开放或客户端暂不支持。本机仍会保存进度。", pending: "上次云端写入结果尚未确认。会先查询核对，避免重复写入。", error: "同步暂未成功，本机进度已保留。可稍后重试。", "too-large": "云存档超过当前单条容量限制，本机进度仍保留。", synced: "已与同账号云存档合并。再次打开时会先读取，营业间歇低频同步。", syncing: "正在核对并合并同账号的进度。", idle: "将在进入小店和营业间歇同步，每分钟最多发起一轮。" };
      return '<section class="settings-page">'.concat(heading("营业手册", "存档与说明"), '<div class="info-section"><h2>进度保存</h2><p data-save-status>').concat(saveLabel(), "</p><p>关键操作后保存本机进度。中途离开会重开当天，未结算收入不会入账；已购买的解锁会保留。</p>").concat(store.localState === "write-error" ? button("重试本机保存", "save-retry", "secondary") : "", '</div><div class="info-section"><h2>云端同步</h2><p>').concat(cloudTexts[store.cloudState], "</p>").concat(store.cloudAvailable ? button("核对并同步", "sync", "secondary") : "", '<p>多设备完成同一天只记一次收入；并发购买合并后按时间核算，可支付的解锁生效。</p></div><div class="info-section"><h2>这一间猫咖</h2><p>八位猫同事，各有脾气。每只猫和每个座位一天只接待一桌。相邻座位的猫若刚吵过，可能会继续拌嘴。</p><p>游戏中的毛类限制属于简化规则，不构成现实中的过敏防护建议。</p><p class="credits">原创猫咪造型与界面 · 场景插画由 AI 辅助生成<br>测试版 0.1.2 · 猫咖接待</p></div><div class="page-bottom">').concat(button("返回", "back", "secondary"), "</div></section>");
    }
    function render() {
      root.classList.toggle("arrange-mode", screen === "arrange");
      root.classList.toggle("many-cats", Boolean(day && day.cats.length > 3));
      if (store.readBlocked) {
        root.innerHTML = '<section class="load-error"><span class="brand-mark">喵</span><h1>营业手册暂时没翻开</h1><p>读取存档失败。原数据已保留，请重试。</p>'.concat(button("重新读取", "retry-load"), "</section>");
        root.removeAttribute("aria-busy");
        return;
      }
      const pages = { home: homePage, cats: catsPage, guest: guestPage, arrange: arrangePage, feedback: feedbackPage, summary: summaryPage, shop: shopPage, ranks: ranksPage, settings: settingsPage };
      root.innerHTML = "".concat(header(), '<div class="page-content">').concat(pages[screen](), "</div>");
      root.removeAttribute("aria-busy");
    }
    function go(next, keepScroll = false) {
      screen = next;
      render();
      if (!keepScroll) window.scrollTo(0, 0);
    }
    async function checkpoint() {
      const saved = await store.save(progress());
      if (!saved) toast("本机保存未确认，请在离开前重试。");
      return saved;
    }
    async function safeSync() {
      if (!["home", "summary", "shop", "settings", "ranks"].includes(screen) || !store.progress) return;
      const before = JSON.stringify(progress());
      await store.sync();
      if (JSON.stringify(progress()) !== before && !["cats", "guest", "arrange", "feedback"].includes(screen)) {
        toast("已合并云端进度。");
        render();
      }
    }
    async function loadRanks(retry = false) {
      const request = ++rankRequest;
      const period = rankPeriod;
      rankValue = null;
      rankError = !rankings.available && !retry;
      rankLoading = !rankError;
      render();
      if (rankError) return;
      try {
        const value = await rankings.list(period);
        if (request === rankRequest) rankValue = value;
      } catch (e) {
        if (request === rankRequest) rankError = true;
      }
      if (request === rankRequest) rankLoading = false;
      if (screen === "ranks" && request === rankRequest) render();
    }
    async function submitRank() {
      if (rankSubmitting) return;
      rankSubmitting = true;
      render();
      const success = await rankings.submit(progress().summary);
      rankSubmitting = false;
      if (screen !== "ranks") return;
      toast(success ? "接待成绩已提交。" : "暂时无法提交成绩，请稍后重试。");
      loadRanks();
    }
    function shareMenu() {
      const shareAvailable = platform.supports(9530, ["share"]);
      const dialog = document.createElement("div");
      dialog.className = "modal-backdrop";
      dialog.innerHTML = '<section class="share-dialog" role="dialog" aria-modal="true" aria-labelledby="share-title"><span class="eyebrow">把好心情带给朋友</span><h2 id="share-title">分享今天的小相遇</h2><p>'.concat(shareAvailable ? "分享结果图或小工具，邀请朋友来当一天接待员。" : "可以直接截取结算页，分享今天最合拍的一对。平台分享需在支持的小红书全屏容器中使用。", "</p>").concat(shareAvailable ? button("分享成果图", "share-image") + button("邀请朋友来玩", "share-card", "secondary") : "").concat(button("回到结算", "close-modal", "quiet"), "</section>");
      document.body.appendChild(dialog);
      const previous = document.activeElement;
      const focusable = Array.from(dialog.querySelectorAll("button"));
      focusable[0].focus();
      dialog.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
          dialog.remove();
          previous.focus();
        }
        if (event.key === "Tab") {
          event.preventDefault();
          const enabled = focusable.filter((node) => !node.disabled);
          const index = enabled.indexOf(document.activeElement);
          enabled[(index + (event.shiftKey ? -1 : 1) + enabled.length) % enabled.length].focus();
        }
      });
      dialog.addEventListener("click", async (event) => {
        const target = event.target.closest("[data-action]");
        if (!target || target.disabled) return;
        if (target.dataset.action === "close-modal") {
          dialog.remove();
          previous.focus();
          return;
        }
        focusable.forEach((node) => {
          node.disabled = node.dataset.action !== "close-modal";
        });
        try {
          const options = target.dataset.action === "share-card" ? { type: "card" } : { type: "image", image_resource: await shareImage() };
          if (!dialog.isConnected) return;
          await platform.api.share(options);
          dialog.remove();
          if (previous.isConnected) previous.focus();
        } catch (e) {
          if (dialog.isConnected) {
            toast("暂时无法发起分享，请稍后重试或截图分享。");
            focusable.forEach((node) => {
              node.disabled = false;
            });
          }
        }
      });
    }
    async function shareImage() {
      const canvas = document.createElement("canvas");
      canvas.width = 750;
      canvas.height = 1e3;
      const ctx = canvas.getContext("2d");
      const summary = progress().summary;
      const { best, review, revenue } = summaryDetails(summary);
      ctx.fillStyle = "#f7f3e9";
      ctx.fillRect(0, 0, 750, 1e3);
      ctx.fillStyle = "#274b3e";
      ctx.font = "bold 32px sans-serif";
      ctx.fillText("猫咖接待 · 第 " + summary.day + " 天", 58, 78);
      ctx.font = "bold 43px sans-serif";
      ctx.fillText("今天最合拍的一对", 58, 145);
      const image = new Image();
      await new Promise((resolve, reject) => {
        image.onload = resolve;
        image.onerror = reject;
        image.src = "./assets/cafe.png";
      });
      ctx.drawImage(image, 0, 0, image.width, image.height, 40, 185, 670, 447);
      if (best) {
        drawShareCat(ctx, best.catId, 540, 520);
        ctx.fillStyle = "#274b3e";
        ctx.font = "bold 36px sans-serif";
        ctx.fillText(guestById(best.guestId).name + " ＆ " + catById(best.catId).name, 58, 692);
      }
      ctx.font = "26px sans-serif";
      ctx.fillText("今日营业额 " + revenue + " 金币", 58, 745);
      ctx.font = "bold 28px sans-serif";
      const characters = Array.from("“" + review + "”");
      let line = "";
      let y = 815;
      characters.forEach((character) => {
        if (ctx.measureText(line + character).width > 625) {
          ctx.fillText(line, 58, y);
          line = "";
          y += 42;
        }
        line += character;
      });
      ctx.fillText(line, 58, y);
      ctx.fillStyle = "#69776d";
      ctx.font = "22px sans-serif";
      ctx.fillText("一位客人，一只猫，一个刚刚好的座位。", 58, 954);
      return canvas.toDataURL("image/png");
    }
    function drawShareCat(ctx, id, x, y) {
      const cat = catById(id);
      ctx.fillStyle = "#fffaf0";
      ctx.beginPath();
      ctx.arc(x, y, 87, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = cat.color;
      ctx.beginPath();
      ctx.moveTo(x - 60, y - 10);
      ctx.lineTo(x - 59, y - 70);
      ctx.lineTo(x - 20, y - 38);
      ctx.lineTo(x + 21, y - 38);
      ctx.lineTo(x + 59, y - 70);
      ctx.lineTo(x + 60, y - 10);
      ctx.ellipse(x, y, 67, 52, 0, 0, Math.PI);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#fff6e3";
      ctx.beginPath();
      ctx.ellipse(x, y + 15, 28, 20, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#263b30";
      [-24, 24].forEach((dx) => {
        ctx.beginPath();
        ctx.ellipse(x + dx, y - 2, 5, id === "C02" || id === "C08" ? 3 : 7, 0, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.fillStyle = "#b87873";
      ctx.beginPath();
      ctx.moveTo(x - 6, y + 10);
      ctx.lineTo(x + 6, y + 10);
      ctx.lineTo(x, y + 17);
      ctx.fill();
      if (id === "C01" || id === "C05" || id === "C07") {
        ctx.fillStyle = "#79562e";
        [-15, 0, 15].forEach((dx) => ctx.fillRect(x + dx - 2, y - 38, 4, 16));
      }
      if (id === "C03") {
        ctx.fillStyle = "#fff6e3";
        ctx.beginPath();
        ctx.moveTo(x, y - 37);
        ctx.lineTo(x - 17, y + 13);
        ctx.lineTo(x + 17, y + 13);
        ctx.fill();
      }
    }
    root.addEventListener("click", async (event) => {
      const target = event.target.closest("[data-action]");
      if (!target || target.disabled) return;
      const action = target.dataset.action;
      if (action === "back" || action === "shop-back") {
        back();
        return;
      }
      if (clickBusy) return;
      const id = target.dataset.id;
      const actionScreen = screen;
      const actionDay = day;
      const saving = ["open", "admit", "continue", "next-day", "buy", "wake", "sync", "save-retry", "retry-load"].includes(action);
      if (saving) {
        target.disabled = true;
        target.setAttribute("aria-busy", "true");
      }
      clickBusy = true;
      try {
        switch (action) {
          case "home":
            returnHome();
            break;
          case "open":
            selection = { cat: null, seat: null };
            day = createDay(progress());
            await checkpoint();
            go("cats");
            break;
          case "guest":
            go("guest");
            break;
          case "arrange":
            go("arrange");
            break;
          case "cat":
            selection.cat = id;
            go("arrange", true);
            break;
          case "seat":
            selection.seat = id;
            go("arrange", true);
            break;
          case "reset":
            selection = { cat: null, seat: null };
            go("arrange", true);
            break;
          case "wake": {
            const status = day.cats.find((cat) => cat.id === id);
            if (!day.wandUsed && available(progress(), "wand") && status.state === "sleep") {
              status.state = "happy";
              day.wandUsed = true;
              await checkpoint();
              toast(catById(id).name + "醒来啦，今天心情好！");
              render();
            }
            break;
          }
          case "admit":
            admit(day, progress(), selection.cat, selection.seat);
            selection = { cat: null, seat: null };
            detailsOpen = false;
            await checkpoint();
            if (screen === actionScreen && day === actionDay) go("feedback");
            break;
          case "details":
            detailsOpen = !detailsOpen;
            render();
            break;
          case "continue":
            if (day.results.length === day.guests.length) {
              finishDay(progress(), day);
              await checkpoint();
              if (screen === actionScreen && day === actionDay) go("summary");
              rankings.submit(progress().summary).then((success) => {
                if (!success && rankings.available) toast("成绩暂未提交，稍后可在排行榜重试。");
              });
            } else go("guest");
            break;
          case "summary":
            go("summary");
            break;
          case "next-day":
            progress().day = Math.max(progress().day, progress().summary.day + 1);
            progress().updatedAt = Date.now();
            await checkpoint();
            if (screen === actionScreen && day === actionDay) {
              day = createDay(progress());
              go("cats");
            }
            break;
          case "shop":
            shopReturn = screen === "summary" ? "summary" : "home";
            go("shop");
            break;
          case "buy":
            if (buy(progress(), id)) {
              await checkpoint();
              render();
              toast("已解锁，下一天开始可用。");
            }
            break;
          case "ranks":
            rankReturn = screen;
            go("ranks");
            loadRanks();
            break;
          case "load-rank":
            loadRanks(true);
            break;
          case "submit-rank":
            submitRank();
            break;
          case "period":
            rankPeriod = id;
            loadRanks();
            break;
          case "share-menu":
            shareMenu();
            break;
          case "settings":
            settingsReturn = screen;
            go("settings");
            break;
          case "save-retry":
            await checkpoint();
            render();
            break;
          case "sync":
            await safeSync();
            render();
            break;
          case "retry-load":
            await store.retryLoad();
            if (!store.readBlocked) {
              await safeSync();
            }
            render();
            break;
        }
      } catch (error) {
        toast(error.message || "这一步暂时没成功，请重试。");
      } finally {
        clickBusy = false;
        if (saving && target.isConnected) {
          target.disabled = false;
          target.removeAttribute("aria-busy");
        }
      }
    });
    await store.load();
    ready = true;
    render();
    if (!store.readBlocked) {
      await safeSync();
      if (store.localState === "new") await store.writeLocal();
    }
    setInterval(() => {
      if (!document.hidden) safeSync();
    }, 6e4);
    document.addEventListener("visibilitychange", () => {
      if (document.hidden && store.progress && !store.readBlocked) store.writeLocal();
    });
  }
  main().catch(() => {
    document.getElementById("app").innerHTML = '<section class="load-error"><h1>猫咖暂时没开好门</h1><p>请关闭后重新进入，已有存档会保留。</p></section>';
  });
})();
